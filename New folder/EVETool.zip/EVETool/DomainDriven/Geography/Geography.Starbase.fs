﻿namespace EveOnline.Geography

module Starbase =     

    type StarbaseFaction = 
    | Minmatar
    | Gallente
    | Caldari
    | Amarr
    | Guristas
    | Sansha
    | BloodRaider
    | Angel
    | Serpentis
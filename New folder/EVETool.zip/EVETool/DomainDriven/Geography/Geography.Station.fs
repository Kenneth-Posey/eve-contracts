﻿namespace EveOnline.Geography

module Station =     

    type PlayerStation = 
    | Minmatar
    | Gallente
    | Caldari
    | Amarr

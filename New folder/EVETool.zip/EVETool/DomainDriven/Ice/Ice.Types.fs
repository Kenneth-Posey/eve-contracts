﻿namespace EveOnline.IceDomain

module Types = 
    type IceType = 
    | BlueIce             
    | ClearIcicle         
    | DarkGlitter         
    | EnrichedClearIcicle 
    | Gelidus             
    | GlacialMass         
    | GlareCrust          
    | Krystallos          
    | PristineWhiteGlaze  
    | SmoothGlacialMass   
    | ThickBlueIce         
    | WhiteGlaze           
    
    
namespace EveOnline

module IceRecords = 
    open EveOnline.ProductTypes
    open EveOnline.ProductRecords
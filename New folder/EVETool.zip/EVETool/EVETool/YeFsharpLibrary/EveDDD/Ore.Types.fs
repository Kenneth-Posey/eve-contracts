namespace EveOnline

module OreTypes = 
    ()
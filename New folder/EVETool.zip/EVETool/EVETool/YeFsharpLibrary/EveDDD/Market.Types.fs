namespace EveOnline

module MarketTypes = 
    ()
namespace EveOnline

module IceTypes = 
    open EveOnline.ProductTypes
    
    
namespace EveOnline

module Product = 
    ()
namespace EveOnline

module ProductTypes = 
    ()
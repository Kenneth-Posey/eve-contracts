namespace EveOnline

module Ore = 
    open EveOnline.ProductTypes
    open EveOnline.OreTypes
    open EveOnline.OreRecords    
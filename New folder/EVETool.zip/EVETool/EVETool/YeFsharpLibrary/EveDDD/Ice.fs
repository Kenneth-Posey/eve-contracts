namespace EveOnline

module Ice = 
    open EveOnline.ProductTypes
    open EveOnline.IceTypes
    open EveOnline.IceRecords

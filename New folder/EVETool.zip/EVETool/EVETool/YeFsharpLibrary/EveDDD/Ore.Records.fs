namespace EveOnline

module OreRecords = 
    open EveOnline.ProductTypes
    open EveOnline.ProductRecords
﻿namespace EveData

module Input = 
    ()